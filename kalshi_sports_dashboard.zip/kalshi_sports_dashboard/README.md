# Kalshi Sports Lab — mobile-friendly, read-only dashboard

## Run locally

Install Python 3.10+, then from this folder:

```bash
pip install -r requirements.txt
streamlit run app.py
```

Open the displayed local URL in a browser. For iPhone access on the same Wi-Fi, run `streamlit run app.py --server.address 0.0.0.0` and visit `http://YOUR_COMPUTER_LAN_IP:8501` from your iPhone. Do not expose this unauthenticated development server to the public internet.

## What is implemented

- Public Kalshi market snapshot collection and recent settlement collection using the bundled `bot.py`.
- SQLite persistent historical snapshots and outcomes, charted on a responsive Streamlit interface.
- CSV import of **independently generated** probabilities with UTC timestamps and source names.
- Historical evaluation against outcomes, with Brier scores and a calibration table.
- Potential value screen using best available stored ask, user-defined fee/slippage allowance, and conservative minimum edge.
- Alerts are **on-screen only**, not push notifications; gated until at least 100 eligible settled forecasts, improved Brier score versus a descriptive constant-rate baseline, and quote freshness <=30 minutes.
- Zero trade execution capabilities. No credentials required.

## Important limitations

This package does **not** contain a trained sports prediction model, historical team/player statistics, or independently validated probability estimates. Kalshi price history is not itself an independent prediction model. The validation monitor is not a substitute for chronological walk-forward validation on separately acquired sports data. Results may be biased by which markets were collected, by data timing, and by correlated forecasts. Outcomes are collected from recent API pages, not an exhaustive historical backfill. Sports discovery is a simple keyword filter; it may miss relevant markets. Fees/slippage are approximated, and the stored ask may not be executable. The dashboard does not send push alerts, and it cannot remain running when the host computer is off. Review Kalshi's current API docs and policies before deployment.

For reliable sports-specific models, add licensed historical scores, injuries, lineups, schedules, and team strength data; train using chronological splits; generate pre-event forecasts; and evaluate on held-out future events before considering alerts actionable.
