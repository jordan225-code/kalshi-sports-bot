# Kalshi Sports Lab v3 — read-only

## Update from iPhone

1. Download `kalshi_sports_lab_v3.zip` and tap it in iPhone Files to unzip.
2. Open your existing GitHub repository `kalshi-sports-bot` in Safari. Replace the old root-level `app.py`, `bot.py`, and `requirements.txt`; add `engine.py`, `storage.py`, `schema.sql`, and this README. **Do not upload the containing folder**: `app.py` must stay in the repository root.
3. GitHub mobile web can edit a file via its pencil icon, or use **Add file → Upload files**; overwrite existing files using the GitHub web editor if upload refuses duplicates. Commit changes to `main`.
4. Streamlit Community Cloud should redeploy automatically. If not, open Manage app → Reboot.

## Data and model

- Import **real historical final-score CSV** in the `Historical games` tab. Required headers: `sport,game_date,home_team,away_team,home_score,away_score`. Use league codes NFL, CFB, NBA, NHL, MLB; ISO dates; exact consistent team names. No bundled or invented historical results.
- The model is a per-league logistic regression using trailing 10 completed games per team. It ignores draws and uses no player injuries, lineups, weather, or bookmaker prices.
- Features for each game use only games dated **before** that game, grouped by day to avoid same-day leakage.
- Most recent 25% of dates are held out chronologically; requires at least 60 training examples and 10 holdout examples per league. These are baseline out-of-sample tests, not proof of future profitability. Repeated model tuning against the same holdout invalidates the test.
- Predictions support **only full-game home-win YES contracts**, not totals, point spreads, derivatives, parlays, or player props. Manual mapping is required; market wording and settlement rules must match. Forecast only games scheduled after all training data.
- Mispricing watchlist computes `model probability - Kalshi YES ask - estimated fee/slippage`. No buy signals are certified; quotes older than 30 minutes are stale.

## Persistent storage (optional)

Streamlit local SQLite and session memory are ephemeral. For durable **historical games and saved forecasts**, create a Supabase project, run `schema.sql` in its SQL editor, and set these values in Streamlit app **Settings → Secrets**:

```toml
SUPABASE_URL = "https://YOUR_PROJECT.supabase.co"
SUPABASE_KEY = "YOUR_SECRET_SERVER_SIDE_KEY"
```

**Security:** a privileged Supabase key can access all tables. Do not put it in GitHub, client-side code, or screenshots. For a public Streamlit dashboard, add access control before configuring privileged credentials. v3 does **not** persist market price snapshots or outcomes to Supabase; those remain in ephemeral SQLite. Automatic scheduled scans, push notifications, full historical backfill, and independently certified probability calibration are **not** implemented.

## Run locally

`pip install -r requirements.txt` then `streamlit run app.py`.

No Kalshi API key, wallet, trading endpoint, or order functionality is used.
