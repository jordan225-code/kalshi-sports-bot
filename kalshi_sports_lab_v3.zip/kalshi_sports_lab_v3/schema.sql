-- Run in Supabase SQL Editor. Keep secret keys OUT of GitHub.
create table if not exists public.games (
 sport text not null, game_date timestamptz not null,
 home_team text not null, away_team text not null,
 home_score double precision not null, away_score double precision not null,
 primary key(sport,game_date,home_team,away_team));
create table if not exists public.forecasts (
 ticker text primary key, sport text not null, home_team text not null,
 away_team text not null, side text not null, probability double precision not null,
 forecast_at timestamptz not null, model_version text not null);
-- API access via server-side secret; do not expose to public browser code.
alter table public.games enable row level security;
alter table public.forecasts enable row level security;
